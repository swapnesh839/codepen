let nav_icon = document.querySelector(".nav-icon");
let navbar = document.querySelector(".navbar");
let navbar_nav = document.querySelector(".navbar-nav");
let nav_brand = document.querySelector(".nav-brand");
let navbar_hidden = document.querySelector(".navbar-hidden");
count = 0;
navbar_hidden.style.color = "white";

nav_icon.addEventListener("click", () => {
  count++;
  if (count == 1) {
    navbar_hidden.style.display = "flex";
  }
  else {
    count = 0;
    navbar_hidden.style.display = "none";
  }
})

let height = document.querySelector("#section1").offsetHeight;
console.log(height);

window.addEventListener("scroll", () => {
  if (document.documentElement.scrollTop > height) {
    navbar.style.height = "4rem"
    nav_brand.style.fontSize = "2rem";
    navbar_nav.style.fontSize = "1.1rem";
  } else {
    navbar.style.height = "3rem";
    nav_brand.style.fontSize = "1.5rem";
    navbar_nav.style.fontSize = "1rem";
  }
})

// navbar ends

const text = "ねえ、あなた！ インドを探索したい場合は、下にスクロールしてください ⏬";
const typewriter = document.getElementById("typewriter");

function animated(text, typewriter) {
  let index = 0;
  setInterval(() => {
    if (index < text.length) {
      typewriter.textContent += text.charAt(index);
      index++;
    } else {
      clearInterval();
    }
  }, 200);
}
animated(text, typewriter);

// animation ended
let content1 = document.querySelector(".content1");
content1.addEventListener("click", () => {
  window.location = "#section2"
})
